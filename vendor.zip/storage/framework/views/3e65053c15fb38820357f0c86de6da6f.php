
<?php $__env->startSection('title'); ?>
    Admin
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="breadcrumb__content">
                        <div class="breadcrumb__content__left">
                            <div class="breadcrumb__title">
                                <h2>Admin List</h2>
                            </div>
                        </div>
                        <div class="breadcrumb__content__right">
                            <nav aria-label="breadcrumb">
                                <ul class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Admin</li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="customers__area bg-style mb-30">
                        <div class="item-title">
                            <div class="col-xs-6">
                                <a href="<?php echo e(route('admin.user.create')); ?>" class="btn btn-md btn-info">Add
                                    Admin</a>
                            </div>
                        </div>
                        <div class="customers__table">
                            <table id="admin_list" class="row-border data-table-filter table-style">
                                <thead>
                                    <tr>
                                        <th>Id</th>
                                        <th>Name</th>
                                        <th>Role</th>
                                        <th>Email</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($user->id); ?></td>
                                            <td><?php echo e($user->name); ?></td>
                                            <td>
                                                <?php
                                                    if ($user->role == 1) {
                                                        echo 'Super Admin';
                                                    } elseif ($user->role == 2) {
                                                        echo 'Sale';
                                                    } elseif ($user->role == 3) {
                                                        echo 'Designer';
                                                    } elseif ($user->role == 4) {
                                                        echo 'Production';
                                                    } elseif ($user->role == 5) {
                                                        echo 'Shipping';
                                                    }
                                                ?>
                                            </td>
                                            <td><?php echo e($user->email); ?></td>
                                            <td>
                                                <div class="action__buttons">
                                                    <a href="<?php echo e(route('admin.user.edit', ['id' => $user->id])); ?>"
                                                        class="btn-action">
                                                        <i class="fa-solid fa-pen-to-square"></i>
                                                    </a>
                                                    <a href="<?php echo e(route('admin.user.delete', ['id' => $user->id])); ?>"
                                                        class="btn-action delete" data-id="<?php echo e($user->id); ?>"
                                                        id="delete_admin">
                                                        <i class="fas fa-trash-alt"></i>
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <script>
        $(document).ready(function() {
            $('#admin_list').DataTable();
        });

        $(document).on('click', '#delete_admin', function(e) {

            const id = $(this).data('id');
            e.preventDefault();
            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: "<?php echo e(route('admin.user.delete')); ?>",
                        method: 'POST',
                        jsonType: 'json',
                        data: {
                            id,
                            "_token": "<?php echo e(csrf_token()); ?>"
                        },
                        success: (data) => {
                            if (data.success) {
                                Swal.fire(
                                    'Deleted!',
                                    'Your file has been deleted.',
                                    'success'
                                )
                                window.location.reload();
                            }

                        }
                    })

                }
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\mydate\my_projects_for_client\sale-project\resources\views/admin/users/index.blade.php ENDPATH**/ ?>