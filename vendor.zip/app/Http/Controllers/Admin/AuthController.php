<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Service\ResponseService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class AuthController extends Controller
{
    use ResponseService;
    public function index()
    {
        return view('admin.login');
    }

    public function login(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'email' => 'required|email',
                'password' => 'required'
            ]);
            if ($validator->fails()) {
                return $this->response(false, $validator->errors()->all());
            } else {
                $auth = Auth::attempt(['email' => $request->email, 'password' => $request->password]);
                if ($auth) {
                    return $this->response(true, ['Login Successfully']);
                } else {
                    return $this->response(false, ['Invalid email and password']);
                }
            }
        } catch (\Throwable $th) {
            return $this->response(false, [$th->getMessage()]);
        }
    }
}
