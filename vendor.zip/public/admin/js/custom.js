(function ($) {
    "use strict";
    //Write you custom code

})(jQuery);
