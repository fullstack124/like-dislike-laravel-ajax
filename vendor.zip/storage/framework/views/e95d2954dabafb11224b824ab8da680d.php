
<?php $__env->startSection('title'); ?>
    View Sale
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="breadcrumb__content">
                        <div class="breadcrumb__content__left">
                            <div class="breadcrumb__title">
                                <h2>View Sale</h2>
                            </div>
                        </div>
                        <div class="breadcrumb__content__right">
                            <nav aria-label="breadcrumb">
                                <ul class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Lead</li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="customers__area bg-style mb-30">
                        <div class="item-title">
                            <div class="col-xs-6">
                                
                            </div>
                        </div>
                        <div class="customers__table">
                            <table id="admin_list" class="row-border data-table-filter table-style">
                                <thead>
                                    <tr>
                                        <th>Id</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Phone</th>
                                        <th>Product</th>
                                        <th>Status</th>
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($lead->id); ?></td>
                                            <td><?php echo e($lead->full_name); ?></td>
                                            <td><?php echo e($lead->email); ?></td>
                                            <td><?php echo e($lead->contact_no); ?></td>
                                            <td><?php echo e($lead->product_name); ?></td>
                                            <td><?php echo e($lead->status); ?></td>
                                            
                                            
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <script>
        $(document).ready(function() {
            $('#admin_list').DataTable();
        });

        // $(document).on('click', '#delete_admin', function(e) {

        //     const id = $(this).data('id');
        //     e.preventDefault();
        //     Swal.fire({
        //         title: 'Are you sure?',
        //         text: "You won't be able to revert this!",
        //         icon: 'warning',
        //         showCancelButton: true,
        //         confirmButtonColor: '#3085d6',
        //         cancelButtonColor: '#d33',
        //         confirmButtonText: 'Yes, delete it!'
        //     }).then((result) => {
        //         if (result.isConfirmed) {
        //             $.ajax({
        //                 url: "<?php echo e(route('admin.lead.delete')); ?>",
        //                 method: 'POST',
        //                 jsonType: 'json',
        //                 data: {
        //                     id,
        //                     "_token": "<?php echo e(csrf_token()); ?>"
        //                 },
        //                 success: (data) => {
        //                     if (data.success) {
        //                         Swal.fire(
        //                             'Deleted!',
        //                             'Your file has been deleted.',
        //                             'success'
        //                         )
        //                         window.location.reload();
        //                     }

        //                 }
        //             })

        //         }
        //     })
        // })

        // $(document).on('click', '#confirm_salte', function(e) { 
        //     const id = $(this).data('id');
        //     e.preventDefault();
        //     Swal.fire({
        //         title: 'Are you sure?',
        //         text: "You want to add to sale",
        //         icon: 'info',
        //         showCancelButton: true,
        //         confirmButtonColor: '#3085d6',
        //         cancelButtonColor: '#d33',
        //         confirmButtonText: 'Yes, Confirm it!'
        //     }).then((result) => {
        //         if (result.isConfirmed) {
        //             $.ajax({
        //                 url: "<?php echo e(route('admin.lead.confirm_sale')); ?>",
        //                 method: 'POST',
        //                 jsonType: 'json',
        //                 data: {
        //                     id,
        //                     "_token": "<?php echo e(csrf_token()); ?>"
        //                 },
        //                 success: (data) => {
        //                     if (data.success) {
        //                         Swal.fire(
        //                             'Confirm!',
        //                             'Your file has been Confirm to sale.',
        //                             'success'
        //                         )
        //                         window.location.reload();
        //                     }

        //                 }
        //             })

        //         }
        //     })
        // })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\mydate\my_projects_for_client\sale-project\resources\views/admin/sales/index.blade.php ENDPATH**/ ?>