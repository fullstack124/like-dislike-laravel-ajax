<?php

use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\AdminController;
use App\Http\Controllers\Admin\AuthController;
use App\Http\Controllers\Admin\LeadController;
use App\Http\Controllers\SaleController;
use Illuminate\Support\Facades\Route;

Route::middleware(['guest'])->group(function () {
    Route::get('/', [AuthController::class, 'index'])->name('admin.login');
    Route::post('/login', [AuthController::class, 'login'])->name('admin.make.login');
});

Route::middleware(['auth'])->group(function () {
    Route::get('/admin/dashboard', [DashboardController::class, 'index'])->name('admin.dashboard');
    Route::get('/admin/logout', [DashboardController::class, 'logout'])->name('admin.logout');

    Route::middleware(['super_admin'])->group(function () {
        Route::get('/admin/user/list', [AdminController::class, 'index'])->name('admin.user.index');
        Route::get('/admin/user/create', [AdminController::class, 'create'])->name('admin.user.create');
        Route::post('/admin/user/store', [AdminController::class, 'store'])->name('admin.user.store');
        Route::get('/admin/user/update/{id}', [AdminController::class, 'edit'])->name('admin.user.edit');
        Route::post('/admin/user/update', [AdminController::class, 'update'])->name('admin.user.update');
        Route::post('/admin/user/delete', [AdminController::class, 'delete'])->name('admin.user.delete');
    });

    Route::middleware(['sale'])->group(function () {
        Route::get('/admin/lead/list', [LeadController::class, 'index'])->name('admin.lead.index');
        Route::get('/admin/leads/create', [LeadController::class, 'create'])->name('admin.lead.create');
        Route::post('/admin/lead/store', [LeadController::class, 'store'])->name('admin.lead.store');
        Route::get('/admin/lead/update/{id}', [LeadController::class, 'edit'])->name('admin.lead.edit');
        Route::post('/admin/lead/update', [LeadController::class, 'update'])->name('admin.lead.update');
        Route::post('/admin/lead/delete', [LeadController::class, 'delete'])->name('admin.lead.delete');
        Route::post('/admin/lead/confirm-sale', [LeadController::class, 'confirm_to_sale'])->name('admin.lead.confirm_sale');
        Route::get('/admin/sale/list', [SaleController::class, 'index'])->name('admin.sale.index');
        Route::get('/admin/follow/up/{id}', [LeadController::class, 'follow_up_view'])->name('admin.lead.follow_up_view');
        Route::post('/admin/add/follow/up', [LeadController::class, 'add_follow'])->name('admin.lead.add_follow');
    });
});
